import firebase from "firebase";
const firebaseApp = firebase.initializeApp({
  
  apiKey: "AIzaSyAn5YFw9nNCNqQX1ZiZmF_HeCJr9DDkLCU",
  authDomain: "mediaclone-849d3.firebaseapp.com",
  projectId: "mediaclone-849d3",
  storageBucket: "mediaclone-849d3.appspot.com",
  messagingSenderId: "992721061801",
  appId: "1:992721061801:web:f128ef47c148153bd926b8",
  measurementId: "G-VZMM1XZCHT"
});

const db = firebaseApp.firestore();
const auth = firebase.auth();
const storage = firebase.storage();

export { db, auth, storage };
